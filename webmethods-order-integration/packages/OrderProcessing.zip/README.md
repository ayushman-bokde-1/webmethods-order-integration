# Package Name : OrderProcessing

This is a webMethods package and requires a webMethods Integration Server to host it. Package versioning and configuration can be found in the package [manifest](./OrderProcessing/manifest.v3) file. Service and API documentation is available on the package's home page http://<server>:<port>/<packagename>.





## Database Details:

PDB Name: INVENTORYPDB

Service Name: inventorypdb.bbrouter

Admin User: inventoryadmin

Admin Password: inventoryadmin123

User: inventory\_user

Password: inventory123

